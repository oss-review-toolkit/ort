#! /bin/sh
test.sh Demo $@
