drop table test;

create table test (
  id          varchar(255)   not null primary key,
  value       varchar(255)
);


exit;
